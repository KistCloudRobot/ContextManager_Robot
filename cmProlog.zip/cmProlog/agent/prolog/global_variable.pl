:- module(global_variable,
    []).
:- use_module(library('prolog/arbi_convenient_service_global_variable')).
:- use_module(library('prolog/predicate__global_variable')).